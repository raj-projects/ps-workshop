import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-cource',
  templateUrl: './cource.component.html',
  styleUrls: ['./cource.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
