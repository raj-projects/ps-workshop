import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-cources',
  templateUrl: './cources.component.html',
  styleUrls: ['./cources.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CourcesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
