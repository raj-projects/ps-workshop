// import { CommonModule } from '@angular/common';
// import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
// import { RouterModule } from '@angular/router';
// import { SharedModule } from '../../shared/shared.module';

// Shared Components
// import { HomeComponent } from './home.component';

// @NgModule({
//   declarations: [
//     HomeComponent
//   ],
//   imports: [
//     CommonModule, 
//     RouterModule.forChild([{path: '', component: HomeComponent}]),
//     SharedModule
//   ],
//   schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
// })
// export class HomeModule { }
