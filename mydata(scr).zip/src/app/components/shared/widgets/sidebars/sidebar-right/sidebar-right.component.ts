import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-sidebar-right',
  templateUrl: './sidebar-right.component.html',
  styleUrls: ['./sidebar-right.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SidebarRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
